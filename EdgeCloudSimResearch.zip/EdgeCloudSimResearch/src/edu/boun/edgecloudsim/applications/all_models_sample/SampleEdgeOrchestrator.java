/*
 * Edge Computing Orchestrator handling All Models T1-T5
 */

 package edu.boun.edgecloudsim.applications.all_models_sample;

 import java.util.List;
 
 import org.cloudbus.cloudsim.Vm;
 import org.cloudbus.cloudsim.core.CloudSim;
 import org.cloudbus.cloudsim.core.SimEvent;

import edu.boun.edgecloudsim.cloud_server.CloudVM;
import edu.boun.edgecloudsim.core.SimManager;
 import edu.boun.edgecloudsim.core.SimSettings;
 import edu.boun.edgecloudsim.edge_orchestrator.EdgeOrchestrator;
 import edu.boun.edgecloudsim.edge_server.EdgeVM;
 import edu.boun.edgecloudsim.edge_client.CpuUtilizationModel_Custom;
 import edu.boun.edgecloudsim.edge_client.Task;
 import edu.boun.edgecloudsim.edge_client.mobile_processing_unit.MobileVM;
 import edu.boun.edgecloudsim.utils.SimLogger;
 
 public class SampleEdgeOrchestrator extends EdgeOrchestrator {
	 
	 private int numberOfHost;
 
	 public SampleEdgeOrchestrator(String _policy, String _simScenario) {
		 super(_policy, _simScenario);
	 }
 
	 @Override
	 public void initialize() {
		 numberOfHost = SimSettings.getInstance().getNumOfEdgeHosts();
	 }
 
	 @Override
	 public int getDeviceToOffload(Task task) {
		 // Validate policy first
		 if(!policy.equals("ONLY_MOBILE") && 
			!policy.equals("ONLY_EDGE") && 
			!policy.equals("ONLY_CLOUD") && 
			!policy.equals("HYBRID_MOBILE_EDGE") && 
			!policy.equals("HYBRID_CLOUD_EDGE")) {
			 SimLogger.printLine("Unknown policy: " + policy);
			 System.exit(0);
		 }
	 
		 // T1: Only Mobile
		 if(policy.equals("ONLY_MOBILE")){
			 return SimSettings.MOBILE_DATACENTER_ID;
		 }
		 // T2: Only Edge
		 else if(policy.equals("ONLY_EDGE")){
			 return SimSettings.GENERIC_EDGE_DEVICE_ID;
		 }
		 // T3: Only Cloud
		 else if(policy.equals("ONLY_CLOUD")){
			 return SimSettings.CLOUD_DATACENTER_ID;
		 }
		 // T5: Mobile-Edge Hybrid
		 else if(policy.equals("HYBRID_MOBILE_EDGE")){
			 List<MobileVM> vmArray = SimManager.getInstance().getMobileServerManager().getVmList(task.getMobileDeviceId());
			 if(vmArray == null || vmArray.isEmpty()) {
				 return SimSettings.GENERIC_EDGE_DEVICE_ID;
			 }
			 
			 double requiredCapacity = ((CpuUtilizationModel_Custom)task.getUtilizationModelCpu())
				 .predictUtilization(vmArray.get(0).getVmType());
			 double availableCapacity = 100 - vmArray.get(0).getCloudletScheduler()
				 .getTotalUtilizationOfCpu(CloudSim.clock());
				 
			 return (requiredCapacity <= availableCapacity) ? 
				 SimSettings.MOBILE_DATACENTER_ID : 
				 SimSettings.GENERIC_EDGE_DEVICE_ID;
		 }
		 // T4: Cloud-Edge Hybrid
		 else { // HYBRID_CLOUD_EDGE
			 List<MobileVM> vmArray = SimManager.getInstance().getMobileServerManager().getVmList(task.getMobileDeviceId());
			 if(vmArray == null || vmArray.isEmpty()) {
				 return SimSettings.CLOUD_DATACENTER_ID;
			 }
			 
			 double requiredCapacity = ((CpuUtilizationModel_Custom)task.getUtilizationModelCpu())
				 .predictUtilization(vmArray.get(0).getVmType());
			 double availableCapacity = 100 - vmArray.get(0).getCloudletScheduler()
				 .getTotalUtilizationOfCpu(CloudSim.clock());
				 
			 return (requiredCapacity <= availableCapacity) ? 
				 SimSettings.GENERIC_EDGE_DEVICE_ID : 
				 SimSettings.CLOUD_DATACENTER_ID;
		 }
	 }
	 
	 @Override
	 public Vm getVmToOffload(Task task, int deviceId) {
		 try {
			 // Validate deviceId first
			 if(deviceId != SimSettings.MOBILE_DATACENTER_ID && 
				deviceId != SimSettings.GENERIC_EDGE_DEVICE_ID && 
				deviceId != SimSettings.CLOUD_DATACENTER_ID) {
				 SimLogger.printLine("Unknown deviceId: " + deviceId);
				 return null;
			 }
	 
			 // Mobile Processing
			 if(deviceId == SimSettings.MOBILE_DATACENTER_ID) {
				 List<MobileVM> vmArray = SimManager.getInstance()
					 .getMobileServerManager()
					 .getVmList(task.getMobileDeviceId());
				 
				 if(vmArray == null || vmArray.isEmpty()) {
					 return null;
				 }
				 
				 MobileVM mobileVM = vmArray.get(0);
				 double requiredCapacity = ((CpuUtilizationModel_Custom)task.getUtilizationModelCpu())
					 .predictUtilization(mobileVM.getVmType());
				 double availableCapacity = 100 - mobileVM.getCloudletScheduler()
					 .getTotalUtilizationOfCpu(CloudSim.clock());
					 
				 return (requiredCapacity <= availableCapacity) ? mobileVM : null;
			 }
			 // Edge Processing
			 else if(deviceId == SimSettings.GENERIC_EDGE_DEVICE_ID) {
				 EdgeVM leastLoadedVM = null;
				 double maxAvailableCapacity = 0;
				 
				 for(int hostIndex = 0; hostIndex < numberOfHost; hostIndex++) {
					 List<EdgeVM> vmArray = SimManager.getInstance()
						 .getEdgeServerManager()
						 .getVmList(hostIndex);
					 
					 if(vmArray != null) {
						 for(EdgeVM vm : vmArray) {
							 double requiredCapacity = ((CpuUtilizationModel_Custom)task.getUtilizationModelCpu())
								 .predictUtilization(vm.getVmType());
							 double availableCapacity = 100 - vm.getCloudletScheduler()
								 .getTotalUtilizationOfCpu(CloudSim.clock());
								 
							 if(requiredCapacity <= availableCapacity && 
								availableCapacity > maxAvailableCapacity) {
								 leastLoadedVM = vm;
								 maxAvailableCapacity = availableCapacity;
							 }
						 }
					 }
				 }
				 return leastLoadedVM;
			 }
			 // Cloud Processing
			 else {
				 List<CloudVM> cloudVmList = SimManager.getInstance()
					 .getCloudServerManager()
					 .getVmList(task.getAssociatedDatacenterId());
				 
				 if(cloudVmList == null || cloudVmList.isEmpty()) {
					 SimLogger.printLine("No Cloud VMs available for task: " + task.getCloudletId());
					 return null;
				 }
				 
				 // Safer index calculation
				 int vmIndex = Math.abs(task.getCloudletId()) % cloudVmList.size();
				 return cloudVmList.get(vmIndex);
			 }
		 } catch (Exception e) {
			 SimLogger.printLine("Error in getVmToOffload for task " + task.getCloudletId() + 
							   ": " + e.getMessage());
			 return null;
		 }
	 }

	 @Override
	 public void processEvent(SimEvent arg0) {
		 // Nothing to do!
	 }
 
	 @Override
	 public void shutdownEntity() {
		 // Nothing to do!
	 }
 
	 @Override
	 public void startEntity() {
		 // Nothing to do!
	 }
 }