package edu.boun.edgecloudsim.applications.all_models_sample;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

import edu.boun.edgecloudsim.core.SimManager;
import edu.boun.edgecloudsim.core.SimSettings;
import edu.boun.edgecloudsim.edge_client.mobile_processing_unit.MobileHost;
import edu.boun.edgecloudsim.edge_client.mobile_processing_unit.MobileServerManager;
import edu.boun.edgecloudsim.edge_client.mobile_processing_unit.MobileVM;
import edu.boun.edgecloudsim.edge_client.mobile_processing_unit.MobileVmAllocationPolicy_Custom;

public class SampleMobileServerManager extends MobileServerManager{
	private int numOfMobileDevices=0;
	
	public SampleMobileServerManager(int _numOfMobileDevices) {
		numOfMobileDevices=_numOfMobileDevices;
	}

	@Override
	public void initialize() {
	}
	
	@Override
	public VmAllocationPolicy getVmAllocationPolicy(List<? extends Host> list, int dataCenterIndex) {
		return new MobileVmAllocationPolicy_Custom(list, dataCenterIndex);
	}

	@Override
	public void startDatacenters() throws Exception {
		localDatacenter = createDatacenter(SimSettings.MOBILE_DATACENTER_ID);
	}

	@Override
	public void terminateDatacenters() {
		localDatacenter.shutdownEntity();
	}

	@Override
	public void createVmList(int brockerId) {
		int vmCounter=SimSettings.getInstance().getNumOfEdgeVMs() + SimSettings.getInstance().getNumOfCloudVMs();
		
		for (int i = 0; i < numOfMobileDevices; i++) {
			vmList.add(i, new ArrayList<MobileVM>());

			String vmm = "Xen";
			int numOfCores = SimSettings.getInstance().getCoreForMobileVM();
			double mips = SimSettings.getInstance().getMipsForMobileVM();
			int ram = SimSettings.getInstance().getRamForMobileVM();
			long storage = SimSettings.getInstance().getStorageForMobileVM();
			long bandwidth = 0;
			
			MobileVM vm = new MobileVM(vmCounter, brockerId, mips, numOfCores, ram, bandwidth, storage, vmm, new CloudletSchedulerTimeShared());
			vmList.get(i).add(vm);
			vmCounter++;
		}
	}

	@Override
	public double getAvgUtilization() {
		double totalUtilization = 0;
		double vmCounter = 0;

		List<? extends Host> list = localDatacenter.getHostList();
		for (int hostIndex=0; hostIndex < list.size(); hostIndex++) {
			List<MobileVM> vmArray = SimManager.getInstance().getMobileServerManager().getVmList(hostIndex);
			for(int vmIndex=0; vmIndex<vmArray.size(); vmIndex++){
				totalUtilization += vmArray.get(vmIndex).getCloudletScheduler().getTotalUtilizationOfCpu(CloudSim.clock());
				vmCounter++;
			}
		}

		return totalUtilization / vmCounter;
	}
	

	private Datacenter createDatacenter(int index) throws Exception{
		String arch = "x86";
		String os = "Linux";
		String vmm = "Xen";
		double costPerBw = 0;
		double costPerSec = 0;
		double costPerMem = 0;
		double costPerStorage = 0;
		
		List<MobileHost> hostList=createHosts();
		
		String name = "MobileDatacenter_" + Integer.toString(index);
		double time_zone = 3.0;         
		LinkedList<Storage> storageList = new LinkedList<Storage>();	

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, costPerSec, costPerMem, costPerStorage, costPerBw);

		Datacenter datacenter = null;
	
		VmAllocationPolicy vm_policy = getVmAllocationPolicy(hostList,index);
		datacenter = new Datacenter(name, characteristics, vm_policy, storageList, 0);
		
		return datacenter;
	}
	
	private List<MobileHost> createHosts(){
		List<MobileHost> hostList = new ArrayList<MobileHost>();
		
		for (int i = 0; i < numOfMobileDevices; i++) {

			int numOfCores = SimSettings.getInstance().getCoreForMobileVM();
			double mips = SimSettings.getInstance().getMipsForMobileVM();
			int ram = SimSettings.getInstance().getRamForMobileVM();
			long storage = SimSettings.getInstance().getStorageForMobileVM();
			long bandwidth = 0;
			
			List<Pe> peList = new ArrayList<Pe>();

			for(int j=0; j<numOfCores; j++){
				peList.add(new Pe(j, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
			}
			
			MobileHost host = new MobileHost(
					i+SimSettings.getInstance().getNumOfEdgeHosts()+SimSettings.getInstance().getNumOfCoudHost(),
					new RamProvisionerSimple(ram),
					new BwProvisionerSimple(bandwidth),
					storage,
					peList,
					new VmSchedulerSpaceShared(peList)
				);
			
			host.setMobileDeviceId(i);
			hostList.add(host);
		}

		return hostList;
	}
	
}
